// pages/fengguang/fengguang.js
Page({
  data:{

    "items": [
      {
        "id": "1",
        "imageUrl": "../../images/OIP-C.jpg",
        "content": "我要导航"
      },
      {
        "id": "2",
        "imageUrl": "../../images/300.jpg",
        "content": "校园标记"
      },
      {
        "id": "3",
        "imageUrl": "../../images/R-C.png",
        "content": "失物招领"
      },
      {
        "id": "4",
        "imageUrl": "../../images/190446aebb24dea91a3fcdc468021ee8.jpg",
        "content": "关于我们"
      }
    ]


  },
  
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  gotoa(e){
  if(e.currentTarget.dataset.id==1){  
   wx.navigateTo({
     url: '/pages/search/search',
   })
    console.log(1)
  }

  if(e.currentTarget.dataset.id==2){
    console.log(2)
  }

  if(e.currentTarget.dataset.id==3){
    console.log(3)
  }

  if(e.currentTarget.dataset.id==4){
    console.log(4)
  }
}
})
