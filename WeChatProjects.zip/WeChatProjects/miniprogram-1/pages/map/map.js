// pages/map/map.js
// index.js
// 获取应用实例
const app = getApp()

Page({
  data: {
    latitude: 30.515331000,
    longitude: 114.4202070000,
    name1 : '华中科技大学沁苑东十一舍',
    name2 : '华中科技大学醉晚亭',
    place1:[1,2],
    place2:[1,2],
    count : 0,
  },
  
  buttonSearch(e,name){
    let _this=this
    let allMarkers = []
    //通过wx.request发起HTTPS接口请求
    wx.request({
      //地图WebserviceAPI地点搜索接口请求路径及参数（具体使用方法请参考开发文档）
      url: `https://apis.map.qq.com/ws/place/v1/search?boundary=region(武汉市,0)&keyword=${name}&page_size=20&page_index=1&key=7XHBZ-OC7CW-DVNRE-RJOMF-QSD23-JYBA4`,
      success(res){
        let result = res.data
        let pois = result.data
        for(let i = 0; i< pois.length; i++){
          let title = pois[i].title
          let lat = pois[i].location.lat
          let lng = pois[i].location.lng
          console.log(title+","+lat+","+lng)

          let marker = {
            id: i,
            latitude: lat,
            longitude: lng,
            callout: {
              // 点击marker展示title
              content: title
            }
          }
          allMarkers.push(marker)
          marker = null
        }
        _this.setData({
          count : _this.data.count+1,
        })

        if(_this.data.count===1)
        {
          _this.place1[0] = marker.latitude;
          _this_place2[1] = marker.longitude;
        }

        else if(_this.data.count==2)
        {
          _this.place2[0] = marker.latitude;
          _this.place2[1] = marker.longitude;
        }

        _this.setData({
          latitude:allMarkers[0].latitude,
          longitude:allMarkers[0].longitude,
        })
       
      },
    })
  },

  button_t(e){
    this.buttonSearch(e,this.data.name1)
  },

  button_x(e){
    this.buttonSearch(e,this.data.name2)
  },
   // 获取当前定位
   getLocation(e){
    let that = this
    wx.getFuzzyLocation({
      type: 'wgs84',
      success (res) {
        // 当前位置坐标
        const latitude = res.latitude;
        const longitude = res.longitude;
        console.log(res);
        // console.log(this.latitude);
        // this.setData({
        //   name:["东九楼"]
        // })

        wx.chooseLocation({
          latitude: res.latitude,
          longitude: res.longitude,
          success: function(data){
          console.log(data)
    }
      })
      },
      fail(err) {
      },
    })
  },

  buttonDriving(e,place1,place2){
    let _this = this
    //通过wx.request发起HTTPS接口请求
    wx.request({
      //地图WebserviceAPI驾车路线规划接口 请求路径及参数（具体使用方法请参考开发文档）
      url: 'https://apis.map.qq.com/ws/direction/v1/driving/?key=7XHBZ-OC7CW-DVNRE-RJOMF-QSD23-JYBA4&from=${place1[0]},${place1[1]}&to=${place2[0]},${place2[1]}',
      success(res){
        let result = res.data.result
        let route = result.routes[0]
        
        let coors = route.polyline, pl = [];
          //坐标解压（返回的点串坐标，通过前向差分进行压缩）
          let kr = 1000000;
          for (var i = 2; i < coors.length; i++) {
            coors[i] = Number(coors[i - 2]) + Number(coors[i]) / kr;
          }
          //将解压后的坐标放入点串数组pl中
          for (var i = 0; i < coors.length; i += 2) {
            pl.push({ latitude: coors[i], longitude: coors[i + 1] })
          }
          _this.setData({
            // 将路线的起点设置为地图中心点
            latitude:pl[0].latitude,
            longitude:pl[0].longitude,
            // 绘制路线
            polyline: [{
              points: pl,
              color: '#58c16c',
              width: 6,
              borderColor: '#2f693c',
              borderWidth: 1
            }]
          })
      }
    })
  },

button_z(e){

  this.buttonDriving(e,this.data.place1,this.data.place2)
},
  maptap(e){
    console.log(this.data.name)
   
  },
  search(){
    console.log(this.data.name)
  },
})