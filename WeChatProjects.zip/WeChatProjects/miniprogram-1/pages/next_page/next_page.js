// pages/next_page/next_page.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    count : 0,
    msg : '请输入文本内容',
    value : 1,
    array: ['1','3','5']
  },
  //这是用来测试按钮的
  btnTapHandler(event){
    console.log(event)
  },
  //这是点击按钮就会加1的
  buttonplusone(){
    //console.log('ok'),
    this.setData({
      count:this.data.count+1
    })
  },
//这是传参数的函数
btnTap2(e){
  console.log(e)
},

//这是测试input的
inputhandle(e){
  console.log(e.detail.value)
  this.setData({
    //msg:this.inputhandle(),
    value : 0
  })
},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})